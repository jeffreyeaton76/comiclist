require 'rails_helper'

RSpec.describe RecordsController, type: :controller do

end
