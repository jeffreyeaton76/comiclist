ComicList

This is a Ruby on Rails app with a React front end. It was created to get some CRUD practice with React.

* Users are able to add comics to the list.
* Users are able to in-line edit existing records.
* The Delete button removes comics from the list.
* Changes to the list affect the total value.